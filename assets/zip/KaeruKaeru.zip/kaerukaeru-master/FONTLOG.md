# FONTLOG for Kaeru Kaeru
This file provides detailed information on the evolutions of the typeface Kaeru Kaeru.

## Basic Font Information
Kaeru Kaeru is a typeface designed by Isabel Motz. It is inspired by poison dart frogs mixed together with the strangely formed muscles in Japanese woodcuts.

## Information for Contributors
See the project website for the current trunk and the various branches:
https://gitlab.com/velvetyne/kaerukaeru 

## ChangeLog
When you make modifications, be sure to add a description of your changes,
following the format of the other entries, to the start of this section.

**2019.07.18 (Isabel Motz) Kaeru Kaeru v0.1**
Initial push of font "Kaeru Kaeru"

## Acknowledgements
When you make modifications, be sure to add your name (N), email (E),
web-address (W) and description (D). This list is sorted by last name in
alphabetical order.

N: Isabel Motz
E: imotz@hfg-karlsruhe.de
W: 
D: Designer